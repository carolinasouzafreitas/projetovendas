/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/**
 *
 * @author aluno
 */
public class ProjetoSistemas {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
